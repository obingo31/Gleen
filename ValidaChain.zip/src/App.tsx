import { useState } from 'react'
import { ShieldCheck } from 'lucide-react'
import CodeInput from './components/CodeInput'
import ValidationResult from './components/ValidationResult'
import { analyzeCode } from './utils/analyzer'

function App() {
  const [code, setCode] = useState('')
  const [results, setResults] = useState<Array<{ 
    issue: string;
    severity: 'high' | 'medium' | 'low';
    description: string;
    source: 'internal' | 'solstatic' | 'stack' | 'getissue';
    line?: number;
    column?: number;
  }>>([])
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  const handleAnalyze = async () => {
    setIsAnalyzing(true)
    try {
      const findings = await analyzeCode(code)
      setResults(findings)
    } catch (error) {
      console.error('Analysis error:', error)
      setResults([{
        issue: 'Analysis Error',
        severity: 'high',
        description: 'An unexpected error occurred during analysis.',
        source: 'internal'
      }])
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div className="min-h-screen p-6 bg-gradient-to-br from-gray-900 via-slate-900 to-gray-900">
      <div className="max-w-4xl mx-auto space-y-8">
        <header className="space-y-3 text-center">
          <h1 className="text-4xl font-bold gradient-text flex items-center justify-center gap-3">
            <ShieldCheck className="w-10 h-10" />
            Smart Contract Validator
          </h1>
          <p className="text-gray-300 text-lg">
            Advanced Smart Contract Validation Analysis Tool
          </p>
        </header>

        <div className="backdrop-blur-lg bg-white/10 rounded-xl p-6 border border-white/20 shadow-xl">
          <CodeInput 
            code={code} 
            onChange={setCode} 
            onAnalyze={handleAnalyze}
            isAnalyzing={isAnalyzing}
          />
        </div>
        
        {results.length > 0 && (
          <div className="backdrop-blur-lg bg-white/10 rounded-xl p-6 border border-white/20 shadow-xl">
            <h2 className="text-2xl font-semibold gradient-text mb-6 flex items-center gap-2">
              <ShieldCheck className="w-6 h-6" />
              Validation Results
            </h2>
            <ValidationResult results={results} />
          </div>
        )}
      </div>
    </div>
  )
}

export default App
