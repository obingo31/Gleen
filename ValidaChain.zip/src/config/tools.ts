export const TOOL_PATHS = {
  STACK_PY: 'stack.py',
  SOLSTATIC_PY: 'solstatic.py',
  MYTHRIL: {
    EXTERNAL_CALLS: 'external_calls.py',
    CHECK_STORAGE: 'check_storage.py',
    CONTRACT_LIST: 'ca_open.txt'
  },
  ETHAINTER: {
    DATALOG: 'getissue.dl',
    OUTPUT: 'GetIssue.csv'
  }
} as const;

export const TOOL_CONFIG = {
  GIGAHORSE_PATH: process.env.GIGAHORSE_PATH || '/usr/local/gigahorse',
  MYTHRIL_TIMEOUT: 120, // seconds
  ANALYSIS_WORKERS: 4,
  CACHE_RESULTS: true,
  CACHE_DURATION: 3600 // 1 hour in seconds
} as const;

export type ToolSource = 'avverifier' | 'mythril' | 'ethainter' | 'internal';

export interface ToolResult {
  source: ToolSource;
  findings: Finding[];
  metadata?: Record<string, unknown>;
}

export interface Finding {
  id: string;
  title: string;
  description: string;
  severity: 'high' | 'medium' | 'low';
  category: string;
  function?: string;
  line?: number;
  column?: number;
  confidence?: 'high' | 'medium' | 'low';
}
