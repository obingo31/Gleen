import { AlertTriangle, AlertOctagon, AlertCircle, Terminal, Shield, Bug } from 'lucide-react'

interface ValidationResultProps {
  results: Array<{
    issue: string
    severity: 'high' | 'medium' | 'low'
    description: string
    source: 'internal' | 'solstatic' | 'stack' | 'getissue'
    line?: number
    column?: number
  }>
}

const severityConfig = {
  high: {
    containerClass: 'bg-red-900/20 text-red-200 border-red-500/30',
    badgeClass: 'bg-red-500/20 text-red-200 border border-red-500/30',
    icon: AlertOctagon
  },
  medium: {
    containerClass: 'bg-yellow-900/20 text-yellow-200 border-yellow-500/30',
    badgeClass: 'bg-yellow-500/20 text-yellow-200 border border-yellow-500/30',
    icon: AlertTriangle
  },
  low: {
    containerClass: 'bg-blue-900/20 text-blue-200 border-blue-500/30',
    badgeClass: 'bg-blue-500/20 text-blue-200 border border-blue-500/30',
    icon: AlertCircle
  },
}

const sourceConfig = {
  internal: {
    icon: Shield,
    label: 'Internal Validator'
  },
  solstatic: {
    icon: Terminal,
    label: 'Solstatic Analysis'
  },
  stack: {
    icon: Bug,
    label: 'Stack Analysis'
  },
  getissue: {
    icon: AlertTriangle,
    label: 'GetIssue Scanner'
  }
}

const ValidationResult = ({ results }: ValidationResultProps) => {
  const issuesByType = {
    high: results.filter(r => r.severity === 'high'),
    medium: results.filter(r => r.severity === 'medium'),
    low: results.filter(r => r.severity === 'low'),
  }

  return (
    <div className="space-y-6">
      {(Object.keys(issuesByType) as Array<keyof typeof issuesByType>).map(severity => {
        const issues = issuesByType[severity]
        if (issues.length === 0) return null

        const { containerClass, badgeClass, icon: Icon } = severityConfig[severity]

        return (
          <div key={severity} className="space-y-3">
            <h3 className="text-lg font-semibold capitalize flex items-center gap-2 text-gray-200">
              <Icon className="w-5 h-5" />
              {severity} Severity Issues
              <span className="text-sm px-2 py-1 rounded-full bg-white/10 text-gray-200 border border-white/20">
                {issues.length}
              </span>
            </h3>
            <div className="space-y-3">
              {issues.map((result, index) => {
                const SourceIcon = sourceConfig[result.source].icon
                
                return (
                  <div
                    key={index}
                    className={`p-4 rounded-lg border backdrop-blur-sm ${containerClass}`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="space-y-1">
                        <h4 className="font-medium">{result.issue}</h4>
                        <div className="flex items-center gap-2 text-xs opacity-80">
                          <div className="flex items-center gap-1">
                            <SourceIcon size={12} />
                            {sourceConfig[result.source].label}
                          </div>
                          {result.line && (
                            <span>Line: {result.line}</span>
                          )}
                        </div>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full ${badgeClass}`}>
                        {result.severity}
                      </span>
                    </div>
                    <p className="text-sm opacity-90">{result.description}</p>
                  </div>
                )
              })}
            </div>
          </div>
        )
      })}
      
      {results.length === 0 && (
        <div className="text-center py-8 text-gray-400">
          No issues found in the contract.
        </div>
      )}
    </div>
  )
}

export default ValidationResult
