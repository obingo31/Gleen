import { Play, Loader } from 'lucide-react'
import { useEffect, useState, lazy, Suspense } from 'react'

const CodeEditor = lazy(() => import('@uiw/react-textarea-code-editor'))

interface CodeInputProps {
  code: string
  onChange: (code: string) => void
  onAnalyze: () => void
  isAnalyzing: boolean
}

const CodeInput = ({ code, onChange, onAnalyze, isAnalyzing }: CodeInputProps) => {
  const [isEditorReady, setIsEditorReady] = useState(false)

  useEffect(() => {
    setIsEditorReady(true)
  }, [])

  return (
    <div className="space-y-4">
      <div>
        <label htmlFor="code-input" className="block text-lg font-medium text-gray-200 mb-1">
          Smart Contract Code
        </label>
        <p className="text-sm text-gray-400">
          Paste your Solidity smart contract code for comprehensive security analysis
        </p>
      </div>
      
      <div className="w-full rounded-lg overflow-hidden bg-black/30 border border-purple-500/30">
        {!isEditorReady ? (
          <div className="h-[400px] flex items-center justify-center">
            <Loader className="w-6 h-6 animate-spin text-purple-500" />
          </div>
        ) : (
          <Suspense fallback={
            <div className="h-[400px] flex items-center justify-center">
              <Loader className="w-6 h-6 animate-spin text-purple-500" />
            </div>
          }>
            <CodeEditor
              value={code}
              language="solidity"
              onChange={(e) => onChange(e.target.value)}
              placeholder="// Paste your Solidity contract here...
contract MyToken {
    mapping(address => uint256) public balances;
    
    function transfer(address to, uint256 amount) public {
        balances[msg.sender] -= amount;
        balances[to] += amount;
    }
}"
              padding={16}
              style={{
                fontSize: 14,
                backgroundColor: "transparent",
                fontFamily: 'ui-monospace,SFMono-Regular,SF Mono,Consolas,Liberation Mono,Menlo,monospace',
                minHeight: '400px',
                color: '#e2e8f0',
              }}
            />
          </Suspense>
        )}
      </div>

      <div className="flex justify-end">
        <button
          onClick={onAnalyze}
          disabled={!code.trim() || isAnalyzing}
          className="flex items-center gap-2 px-6 py-2.5 text-white bg-gradient-to-r from-purple-600 via-blue-600 to-purple-600 rounded-lg 
                     hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300
                     border border-white/20 shadow-lg"
        >
          {isAnalyzing ? (
            <>
              <Loader className="w-4 h-4 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <Play size={18} />
              Analyze Contract
            </>
          )}
        </button>
      </div>
    </div>
  )
}

export default CodeInput
