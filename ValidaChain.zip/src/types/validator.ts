export interface ValidationResult {
  issue: string;
  severity: 'high' | 'medium' | 'low';
  description: string;
}

export interface SymbolicValue {
  type: 'bitvec' | 'memory' | 'bool';
  size?: number;
  annotation: string;
  uid: number;
  value?: any;
  taint?: SymbolicValue | null;
}

export interface EVMState {
  stack: any[];
  memory: Record<string, any>;
  storage: Record<string, any>;
}
