export interface ValidationResult {
  issue: string;
  severity: 'high' | 'medium' | 'low';
  description: string;
  source: 'internal' | 'solstatic' | 'stack' | 'getissue';
  line?: number;
  column?: number;
}

export interface SecurityCheck {
  id: string;
  title: string;
  check: (code: string) => ValidationResult[];
}

export interface AnalysisContext {
  code: string;
  findings: ValidationResult[];
}
