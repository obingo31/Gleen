import type { ValidationResult, SecurityCheck } from '../types/analyzer';
import * as parser from '@solidity-parser/parser';

const securityChecks: SecurityCheck[] = [
  {
    id: 'zero-address',
    title: 'Zero Address Validation',
    check: (code: string): ValidationResult[] => {
      const findings: ValidationResult[] = [];
      
      // Check for address parameters without zero-address validation
      if (code.includes('address') && 
          !code.includes('address(0)') && 
          !code.includes('address(0x0)')) {
        findings.push({
          issue: 'Missing Zero Address Validation',
          severity: 'medium',
          description: 'Contract has address parameters without zero-address validation. Add checks like require(address != address(0)).',
          source: 'internal'
        });
      }
      
      return findings;
    }
  },
  {
    id: 'owner-address',
    title: 'Owner Address Safety',
    check: (code: string): ValidationResult[] => {
      const findings: ValidationResult[] = [];
      
      // Check for owner pattern implementation
      if ((code.includes('owner') || code.includes('admin')) && 
          !code.includes('Ownable') && 
          !code.match(/require\s*\(\s*msg\.sender\s*==\s*owner\s*\)/)) {
        findings.push({
          issue: 'Unsafe Owner Implementation',
          severity: 'high',
          description: 'Owner/admin pattern detected without proper access control. Consider using OpenZeppelin\'s Ownable contract.',
          source: 'internal'
        });
      }
      
      return findings;
    }
  },
  {
    id: 'address-validation',
    title: 'Address Input Validation',
    check: (code: string): ValidationResult[] => {
      const findings: ValidationResult[] = [];
      
      // Check for proper address validation patterns
      if (code.match(/function\s+\w+\s*\([^)]*address[^)]*\)/) && 
          !code.match(/require\s*\([^)]*address/)) {
        findings.push({
          issue: 'Missing Address Validation',
          severity: 'medium',
          description: 'Functions accepting address parameters should validate inputs. Add appropriate require statements.',
          source: 'internal'
        });
      }
      
      return findings;
    }
  },
  {
    id: 'reentrancy',
    title: 'Reentrancy Check',
    check: (code: string): ValidationResult[] => {
      const findings: ValidationResult[] = [];
      
      if ((code.includes('.call{value:') || code.includes('.send(') || code.includes('.transfer(')) &&
          !code.includes('ReentrancyGuard') &&
          !code.includes('nonReentrant')) {
        findings.push({
          issue: 'Reentrancy Vulnerability',
          severity: 'high',
          description: 'Contract uses external calls without reentrancy protection. Implement ReentrancyGuard or checks-effects-interactions pattern.',
          source: 'internal'
        });
      }
      
      return findings;
    }
  },
  {
    id: 'unchecked-calls',
    title: 'Unchecked External Calls',
    check: (code: string): ValidationResult[] => {
      const findings: ValidationResult[] = [];
      
      if (code.includes('.call{') && !code.match(/require\s*\(\s*[\w\s.]*success/)) {
        findings.push({
          issue: 'Unchecked External Call',
          severity: 'high',
          description: 'External call return value is not checked. Always verify the success of external calls.',
          source: 'internal'
        });
      }
      
      return findings;
    }
  },
  {
    id: 'tx-origin',
    title: 'TX.ORIGIN Usage',
    check: (code: string): ValidationResult[] => {
      const findings: ValidationResult[] = [];
      
      if (code.includes('tx.origin')) {
        findings.push({
          issue: 'TX.ORIGIN Usage',
          severity: 'high',
          description: 'Using tx.origin for authentication is vulnerable to phishing. Use msg.sender instead.',
          source: 'internal'
        });
      }
      
      return findings;
    }
  },
  {
    id: 'assembly',
    title: 'Assembly Usage',
    check: (code: string): ValidationResult[] => {
      const findings: ValidationResult[] = [];
      
      if (code.includes('assembly')) {
        findings.push({
          issue: 'Assembly Usage',
          severity: 'medium',
          description: 'Contract uses inline assembly. Ensure proper auditing of assembly code.',
          source: 'internal'
        });
      }
      
      return findings;
    }
  }
];

function parseAndAnalyze(code: string): ValidationResult[] {
  const findings: ValidationResult[] = [];
  
  try {
    // Try to parse the Solidity code
    parser.parse(code, { tolerant: true });
  } catch (e) {
    findings.push({
      issue: 'Parse Error',
      severity: 'high',
      description: 'Contract code could not be parsed. Please verify the syntax.',
      source: 'internal'
    });
    return findings;
  }

  // Run all security checks
  securityChecks.forEach(check => {
    try {
      const checkFindings = check.check(code);
      findings.push(...checkFindings);
    } catch (error) {
      console.error(`Error in security check ${check.id}:`, error);
    }
  });

  return findings;
}

export async function analyzeCode(code: string): Promise<ValidationResult[]> {
  if (!code.trim()) {
    return [{
      issue: 'Empty Contract',
      severity: 'high',
      description: 'The input contract is empty. Please provide smart contract code for analysis.',
      source: 'internal'
    }];
  }

  try {
    const findings = parseAndAnalyze(code);

    // If no issues found, add a success message
    if (findings.length === 0) {
      findings.push({
        issue: 'No Critical Issues',
        severity: 'low',
        description: 'No immediate security concerns found. However, a thorough audit is always recommended.',
        source: 'internal'
      });
    }

    return findings;
  } catch (error) {
    console.error('Analysis error:', error);
    return [{
      issue: 'Analysis Error',
      severity: 'medium',
      description: 'Error running analysis tools. Please try again.',
      source: 'internal'
    }];
  }
}
