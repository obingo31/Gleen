import { SymbolicValue, ValidationResult } from '../types/validator';

let uidCounter = 0;

export class Validator {
  private static createSymbolicValue(type: 'bitvec' | 'memory' | 'bool', annotation: string, size?: number): SymbolicValue {
    return {
      type,
      size,
      annotation,
      uid: ++uidCounter,
      taint: null
    };
  }

  static validateCallerUsage(code: string): ValidationResult[] {
    const results: ValidationResult[] = [];
    
    // Check for msg.sender validation patterns
    if (code.includes('msg.sender') && !code.includes('require(msg.sender')) {
      results.push({
        issue: 'Unprotected msg.sender Usage',
        severity: 'high',
        description: 'Function using msg.sender without proper access control checks.'
      });
    }

    return results;
  }

  static validateStateVariables(code: string): ValidationResult[] {
    const results: ValidationResult[] = [];
    
    // Check state variable visibility
    const stateVarRegex = /\b(uint|int|bool|address|string|bytes)\b(?!\s+.*?(?:public|private|internal))/g;
    if (code.match(stateVarRegex)) {
      results.push({
        issue: 'Missing State Variable Visibility',
        severity: 'medium',
        description: 'State variables should explicitly declare visibility (public, private, or internal).'
      });
    }

    return results;
  }

  static validateFunctionVisibility(code: string): ValidationResult[] {
    const results: ValidationResult[] = [];
    
    // Check function visibility
    const functionRegex = /function\s+\w+\s*\([^)]*\)\s*{/g;
    if (code.match(functionRegex)) {
      results.push({
        issue: 'Missing Function Visibility',
        severity: 'high',
        description: 'Functions must explicitly declare visibility (public, private, internal, or external).'
      });
    }

    return results;
  }

  static validateReentrancy(code: string): ValidationResult[] {
    const results: ValidationResult[] = [];
    
    // Check for potential reentrancy vulnerabilities
    if (
      (code.includes('.call{value:') || code.includes('.send(') || code.includes('.transfer(')) &&
      !code.includes('ReentrancyGuard') &&
      !code.includes('nonReentrant')
    ) {
      results.push({
        issue: 'Reentrancy Vulnerability',
        severity: 'high',
        description: 'Contract uses low-level calls without reentrancy protection. Implement ReentrancyGuard.'
      });
    }

    return results;
  }

  static validateUncheckedCalls(code: string): ValidationResult[] {
    const results: ValidationResult[] = [];
    
    // Check for unchecked external calls
    if (code.includes('.call{') && !code.match(/require\s*\(\s*[\w\s.]*success/)) {
      results.push({
        issue: 'Unchecked External Call',
        severity: 'high',
        description: 'External call return value is not checked. Always verify the success of external calls.'
      });
    }

    // Check for delegatecall to non-constant addresses
    if (code.includes('.delegatecall') && !code.match(/address\s+(?:constant|immutable)/)) {
      results.push({
        issue: 'Non-constant Delegatecall Target',
        severity: 'high',
        description: 'Delegatecall target address should be constant or immutable to prevent potential security issues.'
      });
    }

    // Check LayerZero integration patterns
    if (code.includes('ILayerZeroEndpoint') || code.includes('lzEndpoint')) {
      // Validate proper address encoding in send calls
      const hasLayerZeroSend = code.includes('.send(');
      const hasCorrectEncoding = code.includes('abi.encodePacked(_srcAddress,') ||
                                code.includes('abi.encode(_srcAddress,');
      
      if (hasLayerZeroSend && !hasCorrectEncoding) {
        results.push({
          issue: 'LayerZero Address Encoding Vulnerability',
          severity: 'high',
          description: 'Incorrect address encoding in LayerZero endpoint send calls can lead to permanent fund locks. Ensure source address is properly encoded after destination address.'
        });
      }

      // Check for proper message validation in receive
      const hasReceive = code.includes('lzReceive(');
      const hasSourceValidation = code.includes('validateSender') || 
                                 (code.includes('_srcAddress') && code.includes('require'));
      
      if (hasReceive && !hasSourceValidation) {
        results.push({
          issue: 'Missing LayerZero Source Validation',
          severity: 'high',
          description: 'Cross-chain messages must validate the source address to prevent unauthorized access.'
        });
      }
    }

    return results;
  }
}
