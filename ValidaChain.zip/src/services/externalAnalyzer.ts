import type { ValidationResult, ExternalToolResult } from '../types/analyzer';

// Mock implementations of external tool analysis
export class ExternalAnalyzer {
  static async analyzeSolstatic(code: string): Promise<ExternalToolResult> {
    // Simulate solstatic.py analysis
    const findings = [];
    
    if (code.includes('selfdestruct')) {
      findings.push({
        message: 'Use of selfdestruct detected',
        severity: 'high',
        location: { line: code.split('\n').findIndex(line => line.includes('selfdestruct')) + 1, column: 1 }
      });
    }

    if (code.includes('tx.origin')) {
      findings.push({
        message: 'Use of tx.origin detected',
        severity: 'high',
        location: { line: code.split('\n').findIndex(line => line.includes('tx.origin')) + 1, column: 1 }
      });
    }

    return {
      tool: 'solstatic',
      findings
    };
  }

  static async analyzeStack(code: string): Promise<ExternalToolResult> {
    // Simulate stack.py analysis
    const findings = [];
    
    if (code.includes('assembly')) {
      findings.push({
        message: 'Inline assembly usage detected',
        severity: 'medium',
        location: { line: code.split('\n').findIndex(line => line.includes('assembly')) + 1, column: 1 }
      });
    }

    return {
      tool: 'stack',
      findings
    };
  }

  static async analyzeGetIssue(code: string): Promise<ExternalToolResult> {
    // Simulate getissue.dll analysis
    const findings = [];
    
    if (code.includes('.call(')) {
      findings.push({
        message: 'Low-level call detected',
        severity: 'high',
        location: { line: code.split('\n').findIndex(line => line.includes('.call(')) + 1, column: 1 }
      });
    }

    return {
      tool: 'getissue',
      findings
    };
  }

  static mapSeverity(severity: string): 'high' | 'medium' | 'low' {
    switch (severity.toLowerCase()) {
      case 'critical':
      case 'high':
        return 'high';
      case 'medium':
      case 'warning':
        return 'medium';
      default:
        return 'low';
    }
  }

  static convertToValidationResult(toolResult: ExternalToolResult): ValidationResult[] {
    return toolResult.findings.map(finding => ({
      issue: finding.message,
      severity: this.mapSeverity(finding.severity),
      description: finding.message,
      source: toolResult.tool as any,
      line: finding.location?.line,
      column: finding.location?.column
    }));
  }
}
