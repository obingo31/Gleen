import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs/promises';
import { TOOL_PATHS, TOOL_CONFIG, type ToolResult, type Finding } from '../config/tools';

const execAsync = promisify(exec);

export class ToolRunner {
  static async runAVVerifier(code: string): Promise<ToolResult> {
    try {
      // Run stack.py analysis
      const stackResult = await execAsync(`python3 ${TOOL_PATHS.STACK_PY}`, {
        input: code,
        timeout: TOOL_CONFIG.MYTHRIL_TIMEOUT * 1000
      });

      // Run solstatic.py analysis
      const solstaticResult = await execAsync(`python3 ${TOOL_PATHS.SOLSTATIC_PY}`, {
        input: code,
        timeout: TOOL_CONFIG.MYTHRIL_TIMEOUT * 1000
      });

      const findings: Finding[] = [
        ...this.parseStackOutput(stackResult.stdout),
        ...this.parseSolstaticOutput(solstaticResult.stdout)
      ];

      return {
        source: 'avverifier',
        findings
      };
    } catch (error) {
      console.error('AVVerifier analysis failed:', error);
      throw new Error('AVVerifier analysis failed');
    }
  }

  static async runMythril(code: string): Promise<ToolResult> {
    try {
      // Save contract code temporarily
      const tempFile = `contract_${Date.now()}.sol`;
      await fs.writeFile(tempFile, code);

      // Run external calls analysis
      const externalCallsResult = await execAsync(
        `python3 ${TOOL_PATHS.MYTHRIL.EXTERNAL_CALLS} ${tempFile}`
      );

      // Run storage check analysis
      const storageCheckResult = await execAsync(
        `python3 ${TOOL_PATHS.MYTHRIL.CHECK_STORAGE} ${tempFile}`
      );

      // Cleanup
      await fs.unlink(tempFile);

      const findings: Finding[] = [
        ...this.parseMythrilOutput(externalCallsResult.stdout),
        ...this.parseMythrilOutput(storageCheckResult.stdout)
      ];

      return {
        source: 'mythril',
        findings
      };
    } catch (error) {
      console.error('Mythril analysis failed:', error);
      throw new Error('Mythril analysis failed');
    }
  }

  static async runEthainter(code: string): Promise<ToolResult> {
    try {
      // Save contract code temporarily
      const tempFile = `contract_${Date.now()}.sol`;
      await fs.writeFile(tempFile, code);

      // Run Gigahorse with Ethainter detector
      await execAsync(
        `${TOOL_CONFIG.GIGAHORSE_PATH}/gigahorse.py --analysis ${TOOL_PATHS.ETHAINTER.DATALOG} ${tempFile}`
      );

      // Read and parse results
      const csvContent = await fs.readFile(TOOL_PATHS.ETHAINTER.OUTPUT, 'utf-8');
      const findings = this.parseEthainterCsv(csvContent);

      // Cleanup
      await fs.unlink(tempFile);
      await fs.unlink(TOOL_PATHS.ETHAINTER.OUTPUT);

      return {
        source: 'ethainter',
        findings
      };
    } catch (error) {
      console.error('Ethainter analysis failed:', error);
      throw new Error('Ethainter analysis failed');
    }
  }

  private static parseStackOutput(output: string): Finding[] {
    // Implement parsing logic for stack.py output
    const findings: Finding[] = [];
    const lines = output.split('\n');

    for (const line of lines) {
      if (line.includes('VULNERABILITY')) {
        findings.push({
          id: `STACK_${Date.now()}`,
          title: 'Stack Vulnerability',
          description: line,
          severity: 'high',
          category: 'Stack Analysis',
          confidence: 'high'
        });
      }
    }

    return findings;
  }

  private static parseSolstaticOutput(output: string): Finding[] {
    // Implement parsing logic for solstatic.py output
    const findings: Finding[] = [];
    const lines = output.split('\n');

    for (const line of lines) {
      if (line.includes('ISSUE')) {
        findings.push({
          id: `SOLSTATIC_${Date.now()}`,
          title: 'Static Analysis Issue',
          description: line,
          severity: 'medium',
          category: 'Static Analysis',
          confidence: 'medium'
        });
      }
    }

    return findings;
  }

  private static parseMythrilOutput(output: string): Finding[] {
    // Implement parsing logic for Mythril output
    const findings: Finding[] = [];
    const lines = output.split('\n');

    for (const line of lines) {
      if (line.includes('Issue')) {
        findings.push({
          id: `MYTHRIL_${Date.now()}`,
          title: 'Mythril Security Issue',
          description: line,
          severity: 'high',
          category: 'Mythril Analysis',
          confidence: 'high'
        });
      }
    }

    return findings;
  }

  private static parseEthainterCsv(csvContent: string): Finding[] {
    // Implement parsing logic for Ethainter CSV output
    const findings: Finding[] = [];
    const lines = csvContent.split('\n');

    for (const line of lines) {
      if (line && !line.startsWith('Function')) { // Skip header
        const [func, vulnerability] = line.split(',');
        if (func && vulnerability) {
          findings.push({
            id: `ETHAINTER_${Date.now()}`,
            title: 'Ethainter Vulnerability',
            description: `Vulnerable function detected: ${func}`,
            severity: 'high',
            category: 'Ethainter Analysis',
            function: func.trim(),
            confidence: 'high'
          });
        }
      }
    }

    return findings;
  }
}
